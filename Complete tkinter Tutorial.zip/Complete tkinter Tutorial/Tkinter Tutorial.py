#!/usr/bin/env python
# coding: utf-8

# In[ ]:


#pip install tkinter

#installing TKinter


# This are just snippets bu not the complete  code It only for Explanation Purpose
#fill the appropriate wherever required to get complete output


# In[ ]:


import tkinter as tk


# In[ ]:


window = tk.Tk()


# In[ ]:


greeting = tk.Label(text="Hello, Tkinter")


# In[ ]:


greeting.pack()


# In[ ]:


window.mainloop()


# In[ ]:


label = tk.Label(text="Hello, Tkinter")


# In[ ]:


label = tk.Label(
    text="Hello, Tkinter",
    foreground="white",  # Set the text color to white
    background="black"  # Set the background color to black
)


# In[ ]:


label = tk.Label(text="Hello, Tkinter", background="#34A2FE")


# In[ ]:


label = tk.Label(text="Hello, Tkinter", fg="white", bg="black")


# In[ ]:


label = tk.Label(
    text="Hello, Tkinter",
    fg="white",
    bg="black",
    width=10,
    height=10
)


# In[ ]:


button = tk.Button(
    text="Click me!",
    width=25,
    height=5,
    bg="blue",
    fg="yellow",
)


# In[ ]:


entry = tk.Entry(fg="yellow", bg="blue", width=50)


# In[ ]:


import tkinter as tk
 window = tk.Tk()


# In[ ]:


label = tk.Label(text="Name")
 entry = tk.Entry()


# In[ ]:


label.pack()
 entry.pack()


# In[ ]:


name = entry.get()
 name


# In[ ]:


entry.delete(0)


# In[ ]:


entry.delete(0, 4)


# In[ ]:


entry.delete(0, tk.END)


# In[ ]:


entry.insert(0, "Python")


# In[ ]:


entry.insert(0, "Real ")


# In[ ]:


import tkinter as tk

window = tk.Tk()
frame = tk.Frame()
frame.pack()

window.mainloop()


# In[ ]:


frame = tk.Frame()
label = tk.Label(master=frame)


# In[ ]:


import tkinter as tk

window = tk.Tk()

frame_a = tk.Frame()
frame_b = tk.Frame()

label_a = tk.Label(master=frame_a, text="I'm in Frame A")
label_a.pack()

label_b = tk.Label(master=frame_b, text="I'm in Frame B")
label_b.pack()

frame_a.pack()
frame_b.pack()

window.mainloop()


# In[ ]:


import tkinter as tk

window = tk.Tk()

frame_a = tk.Frame()
label_a = tk.Label(master=frame_a, text="I'm in Frame A")
label_a.pack()

frame_b = tk.Frame()
label_b = tk.Label(master=frame_b, text="I'm in Frame B")
label_b.pack()

# Swap the order of `frame_a` and `frame_b`
frame_b.pack()
frame_a.pack()

window.mainloop()


# In[ ]:


import tkinter as tk

window = tk.Tk()

frame1 = tk.Frame(master=window, width=200, height=100, bg="red")
frame1.pack(fill=tk.BOTH, side=tk.LEFT, expand=True)

frame2 = tk.Frame(master=window, width=100, bg="yellow")
frame2.pack(fill=tk.BOTH, side=tk.LEFT, expand=True)

frame3 = tk.Frame(master=window, width=50, bg="blue")
frame3.pack(fill=tk.BOTH, side=tk.LEFT, expand=True)

window.mainloop()


# In[ ]:


import tkinter as tk

window = tk.Tk()

frame = tk.Frame(master=window, width=150, height=150)
frame.pack()

label1 = tk.Label(master=frame, text="I'm at (0, 0)", bg="red")
label1.place(x=0, y=0)

label2 = tk.Label(master=frame, text="I'm at (75, 75)", bg="yellow")
label2.place(x=75, y=75)

window.mainloop()


# In[ ]:


import tkinter as tk

window = tk.Tk()

for i in range(3):
    for j in range(3):
        frame = tk.Frame(
            master=window,
            relief=tk.RAISED,
            borderwidth=1
        )
        frame.grid(row=i, column=j)
        label = tk.Label(master=frame, text=f"Row {i}\nColumn {j}")
        label.pack()

window.mainloop()


# In[ ]:


import tkinter as tk

window = tk.Tk()

for i in range(3):
    window.columnconfigure(i, weight=1, minsize=75)
    window.rowconfigure(i, weight=1, minsize=50)

    for j in range(0, 3):
        frame = tk.Frame(
            master=window,
            relief=tk.RAISED,
            borderwidth=1
        )
        frame.grid(row=i, column=j, padx=5, pady=5)

        label = tk.Label(master=frame, text=f"Row {i}\nColumn {j}")
        label.pack(padx=5, pady=5)

window.mainloop()


# In[ ]:


#the Code File for Temprature COnvertor App is iin the different file


# In[ ]:





# In[ ]:




