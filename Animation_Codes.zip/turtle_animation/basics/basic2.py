import turtle

# Window and tirtle of screen

wn = turtle.Screen()
wn.title("App 3 - Background Color")

# Set Background Color 
turtle.bgcolor("black")


# Set Pensize
turtle.pensize(3)

# Set Color of Turtle
turtle.color("orange") #You can try different colors here by their name


for i in range(5):
	turtle.circle(50)

	