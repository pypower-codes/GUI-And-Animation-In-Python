import turtle

# Window and tirtle of screen
wn = turtle.Screen()
wn.title("My First Turtle App")


for i in range(10):
	turtle.circle(50)

