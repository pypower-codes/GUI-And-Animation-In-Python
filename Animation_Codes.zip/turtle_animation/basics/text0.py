import turtle


wn = turtle.Screen()
wn.title("App 6 - Text in Turtle")

turtle.pensize(4)


'''Circle'''
turtle.penup()		   
turtle.setpos(-150,120)
turtle.pendown()

turtle.color("blue")
turtle.speed(5)

for i in range(1):
	turtle.circle(50)


# Square
turtle.penup()		   
turtle.setpos(-50,50)
turtle.pendown()	   

turtle.color("red")
turtle.speed(1)        

for i in range(4):
	turtle.forward(100) #Moves 100 steps forward
	turtle.right(90)	#Makes right Turn of 90 degree



# Rectangle
turtle.penup()		   
turtle.setpos(100,-100)
turtle.pendown()

turtle.color("green")
turtle.speed(1)  

for i in range(2):
	turtle.forward(150) #Moves 150 steps forward
	turtle.right(90)	#Makes right Turn of 90 degree
	turtle.forward(70)  #Moves 150 steps forward
	turtle.right(90)	#Makes right Turn of 90 degree



'''TEXT ADDING in Turtle'''
turtle.penup(); turtle.setpos(0,200); turtle.pendown();turtle.color("black")

turtle.write("Text in Turtle", move=True, align="left", font=("Serif", 28))



# Circle Text
turtle.penup(); turtle.setpos(-170,90); turtle.pendown();turtle.color("blue")

turtle.write("Circle", move=True, align="left", font=("Serif", 18))



# Square Text
turtle.penup(); turtle.setpos(-50,70); turtle.pendown();turtle.color("red")

turtle.write("Square", move=False, align="left", font=("Serif", 18))



# Rectangle Text
turtle.penup(); turtle.setpos(100,-80); turtle.pendown();turtle.color("green")

turtle.write("Rectangle", move=False, align="left", font=("Serif", 18))



for i in range(100):
	turtle.circle(0)







