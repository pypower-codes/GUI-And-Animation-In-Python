import turtle

# Window and tirtle of screen

wn = turtle.Screen()
wn.title("Turtle App 2")

# Set Pensize
turtle.pensize(3)

# Set Color of Turtle
turtle.color("Blue")


for i in range(5):
	turtle.circle(50)

