import turtle

wn = turtle.Screen()
wn.title("App 5 - Speed")

turtle.bgcolor("black")

turtle.pensize(3)


'''Circle 1'''
turtle.color("white")
turtle.speed(1)        # Lowest Speed = 1

for i in range(2):
	turtle.circle(50)

turtle.penup()		   # penup() lifts the pen up
turtle.setpos(-100,100)# setpos(x,y)
turtle.pendown()	   # pendown() keeps the pen down




'''Circle 2'''
turtle.color("yellow")
turtle.speed(10)        # Speed Ranges from 1 to 10

for i in range(3):
	turtle.circle(75)

turtle.penup()		   # penup() lifts the pen up
turtle.setpos(150,-150)# setpos(x,y)
turtle.pendown()	   # pendown() keeps the pen down




'''Circle 3'''
turtle.color("red")
turtle.speed(0)        # Maximum Speed

for i in range(10):
	turtle.circle(100)

