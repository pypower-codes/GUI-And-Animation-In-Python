import turtle

wn = turtle.Screen()
wn.title("App 4 - Set Position")

turtle.bgcolor("black")

turtle.pensize(3)


'''Circle 1'''
turtle.color("white")

for i in range(2):
	turtle.circle(50)

turtle.penup()		   # penup() lifts the pen up
turtle.setpos(-100,100)# setpos(x,y)
turtle.pendown()	   # pendown() keeps the pen down




'''Circle 2'''
turtle.color("yellow")

for i in range(2):
	turtle.circle(75)

turtle.penup()		   # penup() lifts the pen up
turtle.setpos(150,-150)# setpos(x,y)
turtle.pendown()	   # pendown() keeps the pen down




'''Circle 3'''
turtle.color("red")

for i in range(5):
	turtle.circle(100)

