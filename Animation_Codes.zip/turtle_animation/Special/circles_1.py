
import turtle

turtle.color("white") #Turtle Pointer Color
rad=180  
turtle.pensize(2)	  #Pensize
turtle.setpos(0,-100) #Position

turtle.color("blue")
turtle.speed(0)      #Speed
  
while rad!=10:
	turtle.circle(rad) #Circle
	rad-=10

turtle.speed(1)
for i in range(1000):   #Rotations
    turtle.circle(1)