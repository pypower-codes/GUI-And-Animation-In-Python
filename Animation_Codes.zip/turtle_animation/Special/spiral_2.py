
import turtle

turtle.color("white")
rad=180  
turtle.pensize(2)
turtle.setpos(0,-100)

turtle.color("blue")
turtle.speed(8)
  
while rad!=10:
    #col=random.randint(0,6)
    #turtle.color(colors[col])
    turtle.circle(rad)
    rad-=10

turtle.speed(1)
for i in range(1000):
    turtle.circle(1)