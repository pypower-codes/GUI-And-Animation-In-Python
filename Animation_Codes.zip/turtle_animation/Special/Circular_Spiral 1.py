
import turtle

window = turtle.Screen()

window.title("Circular Spiral 1")

turtle=turtle.Turtle()
turtle.speed(0)

for i in range(400):
    turtle.circle(i*2)
    turtle._rotate(5)
    
