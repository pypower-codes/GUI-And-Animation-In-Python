
import turtle

t = turtle.Turtle()

t.speed(50)

for i in range(24):    #For 24 Spokes of Ashok Chakra
    t.forward(50)
    t.penup()
    t.setpos(0,0)
    t.pendown()
    t.right(15)         #360/24 = 15 degrees
    
t.setposition(0,-51)
t.circle(52)
t.penup()

t.speed(5)

t.setposition(-450,120)    #For Orange Section of Flag
t.pendown()
t.fillcolor("orange")
t.begin_fill()
t.forward(900)
t.left(90)
t.forward(180)
t.left(90)
t.forward(900)
t.left(90)
t.forward(180)
t.end_fill()
t.penup()


t.setposition(-450,-120)     #For Green Section of Flag
t.pendown()
t.fillcolor("green")
t.begin_fill()
t.right(270)
t.forward(900)
t.right(90)
t.forward(180)
t.right(90)
t.forward(900)
t.right(90)
t.forward(180)
t.end_fill()

for i in range(100):
    turtle.circle(0)