
import turtle

colors = ["red","green","blue","yellow","purple","orange","white"]
colors1 = ["red","yellow","red","yellow","red","yellow","red"]

turtle.bgcolor("black")
turtle.pensize(2)
turtle.speed(0)

for i in range(50):
    for color in ["white"]: #Use colors,colors1 list
        turtle.color(color)
        turtle.left(12)
        
        turtle.forward(130) #Makes a square and then rotate 12 degree left
        turtle.left(90)
        turtle.forward(130)
        turtle.left(90)
        turtle.forward(130)
        turtle.left(90)
        turtle.forward(130)
        turtle.left(90)
        

for i in range(1000):
    turtle.circle(0)