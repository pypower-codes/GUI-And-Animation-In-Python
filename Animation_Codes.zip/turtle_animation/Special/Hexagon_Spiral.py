
import turtle

colors = ["red","green","blue","yellow","purple","orange"]

t = turtle.Pen()
turtle.bgcolor("black")
t1=turtle.Turtle() 
t1.speed(0)

#Making a Hexagon in loop
for i in range(250):
    t.pencolor(colors[i%6])
    t.width(i/100 + 2)
    t.forward(i)
    t.left(59) #6 times rotation at this angle makes 360 complete
               #Exact 60deg will make only one hexagon
               
for i in range(1000):
    turtle.circle(0)
