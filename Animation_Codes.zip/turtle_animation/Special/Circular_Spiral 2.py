import turtle
 
t = turtle.Screen()
t.title("Circular Spiral 2")
 
t.bgcolor("black") 
turtle.pencolor("blue")
turtle.speed(0)
 
t=turtle.Turtle() 
turtle.penup()
 
turtle.setposition(-30,-30)
 
turtle.pendown()
turtle.pensize(1)

colors = ["red","yellow","blue","green","white"]
 
for i in range(1000):
    for c in ["red","yellow"]:
        turtle.color(c)
        turtle.circle(i*2)
        turtle.left(5)
        
        
        
        