
import turtle

turtle.bgcolor("white")
turtle.speed(0)
turtle.pensize(1.25)

color = ["red","orange","blue","green"]

for x in range(360):
    turtle.pencolor(color[x%4])
    turtle.circle(x)
    turtle.left(90)