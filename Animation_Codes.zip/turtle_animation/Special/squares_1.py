
import turtle
import random

colors=["white","red","yellow","cyan","orange","pink","grey"]
turtle.bgcolor("black")
turtle.color("black")
turtle.pensize(5)
turtle.setpos(-320,320)


def spiral(m,n,a):
    k=0
    l=0
    f=32
    col=0

    turtle.color("yellow")
    turtle.speed(20)
    
    while (k<m and l<n):
        for i in range(l,n):
            col=random.randint(0,6)
            turtle.forward(f)
                    
        k+=1
        turtle.right(90)
        for i in range(k,m):
            col=random.randint(0,6)
            turtle.forward(f)
        n-=1
        turtle.right(90)
        
        if(k<m):
            for i in range(n-1,l-1,-1):
                col=random.randint(0,6)
                turtle.forward(f)
            m-=1
            turtle.right(90)
            
        if(l<n):
            for i in range(m-1,k-1,-1):
                col=random.randint(0,6)
                turtle.forward(f)
            l+=1
            turtle.right(90)

m=20
a=[]
count=1
for i in range(m):
    l=[]
    for i in range(m):
        l.append(count)
        count+=1
    a.append(l)
    
spiral(m,m,a)

turtle.speed(1)
for i in range(1000):
    turtle.circle(0)



















